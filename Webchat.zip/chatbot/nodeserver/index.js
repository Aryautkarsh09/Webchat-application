//handles node server socket connections
const io=require('socket.io')(80)
//creating the object users to store names
const users={}


io.on('connection',socket=>{
 //Switching on the newjoined event emitted from client side
    socket.on("newjoined",function(names){

        
        users[socket.id]=names;
        socket.broadcast.emit('usercame',names);
        
    });
    //Switching on the sent event emitted from client side
    socket.on('sent',message=>{
        socket.broadcast.emit('recieve',{message:message,name:users[socket.id]})

    });
    //Switching on the disconnect event 
    socket.on('disconnect', message =>{
        socket.broadcast.emit('gone', users[socket.id]);
        //deleting the name of user who left from list of users
        delete users[socket.id];
    });
})