
const socket=io('http://localhost:80')
// For getting elements of DOM in respective JS variables
const form =document.getElementById('sent-container')
const message_input=document.getElementById("INPUTmessage")
const messageContainer=document.querySelector(".container")
//Including the file from which audio will play when a message arrives
 var notification = new Audio('lo.wav');

 //Function to append information/message on the screen 
const append = (message,position)=>{
const messageElement = document.createElement('div');

messageElement.innerText=message;
messageElement.classList.add('MESSAGE');
messageElement.classList.add(position);
messageContainer.append(messageElement);
//specifying the condition for playing the notification sound
if(position=='left'){
notification.play();
}
}
//Adding event listener of submit for form created in the webpage 

form.addEventListener('submit',(e)=>{
e.preventDefault();
const mess=message_input.value;
append(`You:${mess}`,'right');
socket.emit('sent',mess);
message_input.value='';


})
//Asking the name of user and giving the information to server
const names =prompt("Welcome to webchat!!Please enter the name to join");
socket.emit('newjoined', names );

//If a new user comes ,taking information from the server and appending the message on screen
socket.on('usercame',names =>{
append(`${names} joined the chat`,'right');
})

//Recieving the message from server
socket.on('recieve',data_r =>{
append(`${data_r.name}: ${data_r.message}`,'left');
})

//Appends the message on the chat container when a user leaves the chat
socket.on('gone',name =>{
append(`${name} left the chat`,'left');
})


